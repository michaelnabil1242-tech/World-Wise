import { createContext, useContext, useState, useEffect } from "react";

// 1) create context
const citiesContext = createContext();
// 2) create provider
function CitiesProvider({ children }) {
  const [cities, setCities] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentCity, setCurrentCity] = useState({});
  const URL = "http://localhost:8000";

  useEffect(function () {
    const controller = new AbortController();
    async function getCities() {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetch(`${URL}/cities`, { signal: controller.signal });
        if (!res.ok) throw new Error("Failed To Fetch Cities");
        const data = await res.json();
        setCities(data);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(err.message);
        }
      } finally {
        setIsLoading(false);
      }
    }
    getCities();
    return function () {
      controller.abort();
    };
  }, []);
  // current city function
  async function getCity(id) {
    const controller = new AbortController();
    try {
      setIsLoading(true);
      setError(null);
      const res = await fetch(`${URL}/cities/${id}`, {
        signal: controller.signal,
      });
      if (!res.ok) throw new Error("failed to fetch current City");
      const data = await res.json();
      setCurrentCity(data);
    } catch (err) {
      if (err.name !== "abortController") setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <citiesContext.Provider value={{ cities, isLoading, currentCity, getCity }}>
      {children}
    </citiesContext.Provider>
  );
}
// 3) create custom hook
function useCities() {
  const context = useContext(citiesContext);
  if (context === "undefined")
    throw new Error("the context is used outside of the provider range");
  return context;
}

export { CitiesProvider, useCities };
